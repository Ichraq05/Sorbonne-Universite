package pobj.micros.scheduler;

public interface IService {
	public String getName();
	public int getVersion();
}
