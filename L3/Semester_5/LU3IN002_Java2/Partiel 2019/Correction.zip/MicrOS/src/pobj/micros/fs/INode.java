package pobj.micros.fs;

public interface INode {
	public String getName();
	public INode copy();
}
