package pobj.micros.errors;

@SuppressWarnings("serial")
public class OSError extends Exception {
	
	public OSError(String msg) {
		super(msg);
	}

}